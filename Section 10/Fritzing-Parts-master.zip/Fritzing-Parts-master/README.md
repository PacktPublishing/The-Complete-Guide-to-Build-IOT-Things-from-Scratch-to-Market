# Fritzing-Parts
A collection of home-made Fritzing parts

## ESP-01
The ESP-01 board based on Espressif esp8266 chip
Shameless copy from somewhere on the internet.

## ESP-12
The ESP-12 board based on Espressif esp8266 chip

## DSUN-DC Adapter
DSUN-DC Adapter with variable input/output voltages (from [Ebay](http://www.ebay.com/sch/i.html?_odkw=3A+DC-DC+Converter+Adjustable+Step+down+Power+Supply+Module+replace+LM2596s+FO&_from=R40&_osacat=0&_from=R40&_trksid=p2045573.m570.l1313.TR0.TRC0.H0.X3A+DC-DC+Converter+Adjustable+Step+down+LM2596s.TRS0&_nkw=3A+DC-DC+Converter+Adjustable+Step+down+LM2596s&ghostText=&_sacat=0))

## SRD-5VDC-SL-C
Part for the Songle SRD-5VDC-SL-C relay, courtesy of https://code.google.com/p/fritzing/issues/detail?id=2389
Fixed incorrect pin names